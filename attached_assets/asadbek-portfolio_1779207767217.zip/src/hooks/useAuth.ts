import { useEffect } from 'react';
import { useAuthStore } from '@/store/useAuthStore';

export function useAuth() {
  const store = useAuthStore();

  useEffect(() => {
    store.checkSession();
  }, []);

  return store;
}
