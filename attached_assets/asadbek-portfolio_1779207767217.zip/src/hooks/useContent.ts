import { useEffect } from 'react';
import { useContentStore } from '@/store/useContentStore';
import { contentService } from '@/services/contentService';

export function useContent() {
  const store = useContentStore();

  useEffect(() => {
    const fetchAll = async () => {
      store.setLoading(true);
      try {
        const [settings, hero, about, skills, projects, social, seo] = await Promise.all([
          contentService.getSiteSettings().catch(() => null),
          contentService.getHeroSection().catch(() => null),
          contentService.getAboutSection().catch(() => null),
          contentService.getSkills().catch(() => []),
          contentService.getProjects().catch(() => []),
          contentService.getSocialLinks().catch(() => []),
          contentService.getSEOSettings().catch(() => null),
        ]);

        if (settings) store.setSettings(settings);
        if (hero) store.setHero(hero);
        if (about) store.setAbout(about);
        store.setSkills(skills);
        store.setProjects(projects);
        store.setSocialLinks(social);
        if (seo) store.setSEO(seo);
      } catch (err) {
        store.setError((err as Error).message);
      } finally {
        store.setLoading(false);
      }
    };

    fetchAll();
  }, []);

  return store;
}
