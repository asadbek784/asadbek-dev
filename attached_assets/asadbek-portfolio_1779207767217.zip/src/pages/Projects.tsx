import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, ExternalLink, Github, Search, Filter } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { SectionTitle } from '@/components/ui/SectionTitle';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { useContent } from '@/hooks/useContent';
import { fadeInUp, staggerContainer, scaleIn } from '@/animations/variants';

export function Projects() {
  const { projects, loading } = useContent();
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<'all' | 'featured'>('all');

  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         project.short_description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filter === 'all' || (filter === 'featured' && project.featured);
    return matchesSearch && matchesFilter;
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="pt-20">
      <section className="section-padding py-16 max-w-7xl mx-auto">
        <SectionTitle 
          title="All Projects" 
          subtitle="Explore my complete portfolio of work"
        />

        {/* Search & Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row gap-4 mb-12"
        >
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              placeholder="Search projects..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white placeholder-gray-500 focus:outline-none focus:border-cyber-blue/50 transition-colors"
            />
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setFilter('all')}
              className={`px-6 py-3 rounded-xl font-medium text-sm transition-all ${
                filter === 'all' 
                  ? 'bg-gradient-to-r from-cyber-blue to-cyber-purple text-white' 
                  : 'bg-glass-light text-gray-400 hover:text-white border border-glass-border'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilter('featured')}
              className={`px-6 py-3 rounded-xl font-medium text-sm transition-all ${
                filter === 'featured' 
                  ? 'bg-gradient-to-r from-cyber-blue to-cyber-purple text-white' 
                  : 'bg-glass-light text-gray-400 hover:text-white border border-glass-border'
              }`}
            >
              Featured
            </button>
          </div>
        </motion.div>

        {/* Projects Grid */}
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project) => (
              <motion.div
                key={project.id}
                layout
                variants={fadeInUp}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
              >
                <GlassCard className="group overflow-hidden p-0 h-full flex flex-col">
                  <div className="relative aspect-video overflow-hidden">
                    {project.thumbnail_url ? (
                      <img 
                        src={project.thumbnail_url} 
                        alt={project.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center">
                        <Filter className="w-12 h-12 text-cyber-blue/50" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-cyber-dark via-transparent to-transparent opacity-60" />

                    {project.featured && (
                      <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-gradient-to-r from-cyber-blue to-cyber-purple text-xs font-bold text-white">
                        Featured
                      </div>
                    )}
                  </div>

                  <div className="p-6 flex-1 flex flex-col">
                    <h3 className="text-xl font-bold text-white group-hover:text-cyber-blue transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-gray-400 text-sm mt-2 flex-1">
                      {project.short_description}
                    </p>

                    <div className="flex items-center gap-3 mt-4 pt-4 border-t border-glass-border">
                      <Link 
                        to={`/projects/${project.slug}`}
                        className="flex items-center gap-1 text-cyber-blue text-sm font-medium hover:underline"
                      >
                        Details <ArrowRight className="w-4 h-4" />
                      </Link>

                      {project.github_url && (
                        <a 
                          href={project.github_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-gray-400 hover:text-white transition-colors"
                        >
                          <Github className="w-5 h-5" />
                        </a>
                      )}

                      {project.live_url && (
                        <a 
                          href={project.live_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-gray-400 hover:text-white transition-colors"
                        >
                          <ExternalLink className="w-5 h-5" />
                        </a>
                      )}
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {filteredProjects.length === 0 && (
          <div className="text-center py-20">
            <Filter className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-500">No projects found matching your criteria.</p>
          </div>
        )}
      </section>
    </div>
  );
}
