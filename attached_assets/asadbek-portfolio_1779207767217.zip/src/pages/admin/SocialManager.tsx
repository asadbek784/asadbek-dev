import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Pencil, Trash2, X, Save, Link, Globe, Eye, EyeOff } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { useContent } from '@/hooks/useContent';
import { contentService } from '@/services/contentService';
import { fadeInUp, staggerContainer } from '@/animations/variants';
import type { SocialLink } from '@/types';
import toast from 'react-hot-toast';

const platformOptions = [
  { value: 'github', label: 'GitHub' },
  { value: 'linkedin', label: 'LinkedIn' },
  { value: 'twitter', label: 'Twitter/X' },
  { value: 'website', label: 'Website' },
  { value: 'instagram', label: 'Instagram' },
  { value: 'youtube', label: 'YouTube' },
  { value: 'dribbble', label: 'Dribbble' },
  { value: 'behance', label: 'Behance' },
  { value: 'telegram', label: 'Telegram' },
  { value: 'discord', label: 'Discord' },
];

export function SocialManager() {
  const { socialLinks, setSocialLinks } = useContent();
  const [isEditing, setIsEditing] = useState(false);
  const [editingLink, setEditingLink] = useState<Partial<SocialLink>>({});
  const [saving, setSaving] = useState(false);

  const handleCreate = () => {
    setEditingLink({ platform: 'github', url: '', icon_key: 'github', visible: true, sort_order: socialLinks.length });
    setIsEditing(true);
  };

  const handleEdit = (link: SocialLink) => {
    setEditingLink({ ...link });
    setIsEditing(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure?')) return;
    try {
      await contentService.deleteSocialLink(id);
      setSocialLinks(socialLinks.filter(l => l.id !== id));
      toast.success('Link deleted!');
    } catch (err) {
      toast.error('Failed to delete');
    }
  };

  const handleToggleVisibility = async (link: SocialLink) => {
    try {
      const updated = await contentService.updateSocialLink(link.id, { visible: !link.visible });
      setSocialLinks(socialLinks.map(l => l.id === updated.id ? updated : l));
      toast.success(updated.visible ? 'Link visible' : 'Link hidden');
    } catch (err) {
      toast.error('Failed to update');
    }
  };

  const handleSave = async () => {
    if (!editingLink.platform || !editingLink.url) return;
    setSaving(true);
    try {
      if (editingLink.id) {
        const updated = await contentService.updateSocialLink(editingLink.id, editingLink);
        setSocialLinks(socialLinks.map(l => l.id === updated.id ? updated : l));
        toast.success('Link updated!');
      } else {
        const created = await contentService.createSocialLink(editingLink as Omit<SocialLink, 'id'>);
        setSocialLinks([...socialLinks, created]);
        toast.success('Link created!');
      }
      setIsEditing(false);
      setEditingLink({});
    } catch (err) {
      toast.error('Failed to save');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Social Links</h1>
            <p className="text-gray-500 mt-1">Manage your social media and contact links.</p>
          </div>
          <button onClick={handleCreate} className="btn-primary flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Add Link
          </button>
        </div>
      </motion.div>

      <motion.div variants={staggerContainer} initial="hidden" animate="visible" className="space-y-3">
        {socialLinks.map((link) => (
          <motion.div key={link.id} variants={fadeInUp}>
            <GlassCard className="group">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center">
                    <Globe className="w-5 h-5 text-cyber-blue" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white capitalize">{link.platform}</h3>
                    <p className="text-xs text-gray-500">{link.url}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleToggleVisibility(link)}
                    className={`p-2 rounded-lg transition-colors ${
                      link.visible ? 'text-green-400 hover:bg-green-500/10' : 'text-gray-600 hover:bg-glass-medium'
                    }`}
                    title={link.visible ? 'Visible' : 'Hidden'}
                  >
                    {link.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => handleEdit(link)}
                    className="p-2 rounded-lg hover:bg-glass-medium text-gray-400 hover:text-cyber-blue transition-colors"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(link.id)}
                    className="p-2 rounded-lg hover:bg-red-500/10 text-gray-400 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </motion.div>

      {socialLinks.length === 0 && (
        <div className="text-center py-20">
          <Link className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-500">No social links yet. Click "Add Link" to get started.</p>
        </div>
      )}

      {/* Edit Modal */}
      <AnimatePresence>
        {isEditing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => setIsEditing(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md"
            >
              <GlassCard className="neon-border">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-white">
                    {editingLink.id ? 'Edit Link' : 'New Link'}
                  </h2>
                  <button onClick={() => setIsEditing(false)} className="p-2 rounded-lg hover:bg-glass-medium text-gray-400">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Platform</label>
                    <select
                      value={editingLink.platform || 'github'}
                      onChange={(e) => setEditingLink({ ...editingLink, platform: e.target.value, icon_key: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                    >
                      {platformOptions.map(p => (
                        <option key={p.value} value={p.value} className="bg-cyber-dark">{p.label}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">URL</label>
                    <input
                      type="url"
                      value={editingLink.url || ''}
                      onChange={(e) => setEditingLink({ ...editingLink, url: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                      placeholder="https://..."
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="visible"
                      checked={editingLink.visible !== false}
                      onChange={(e) => setEditingLink({ ...editingLink, visible: e.target.checked })}
                      className="w-4 h-4 rounded border-glass-border bg-glass-light text-cyber-blue"
                    />
                    <label htmlFor="visible" className="text-sm text-gray-300">Visible on site</label>
                  </div>
                </div>

                <div className="flex gap-3 mt-6">
                  <button onClick={() => setIsEditing(false)} className="btn-secondary flex-1">Cancel</button>
                  <button
                    onClick={handleSave}
                    disabled={saving}
                    className="btn-primary flex-1 flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {saving ? <LoadingSpinner size="sm" /> : <Save className="w-4 h-4" />}
                    Save
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
