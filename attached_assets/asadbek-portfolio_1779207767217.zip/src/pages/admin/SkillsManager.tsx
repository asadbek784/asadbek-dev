import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Pencil, Trash2, X, Save, Code } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { useContent } from '@/hooks/useContent';
import { contentService } from '@/services/contentService';
import { fadeInUp, staggerContainer } from '@/animations/variants';
import type { Skill } from '@/types';
import toast from 'react-hot-toast';

const categories = [
  { value: 'frontend', label: 'Frontend' },
  { value: 'backend', label: 'Backend' },
  { value: 'design', label: 'Design' },
  { value: 'tools', label: 'Tools & DevOps' },
  { value: 'other', label: 'Other' },
];

export function SkillsManager() {
  const { skills, setSkills } = useContent();
  const [isEditing, setIsEditing] = useState(false);
  const [editingSkill, setEditingSkill] = useState<Partial<Skill>>({});
  const [saving, setSaving] = useState(false);

  const handleCreate = () => {
    setEditingSkill({ name: '', icon_key: 'code', proficiency: 50, category: 'frontend' });
    setIsEditing(true);
  };

  const handleEdit = (skill: Skill) => {
    setEditingSkill({ ...skill });
    setIsEditing(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this skill?')) return;
    try {
      await contentService.deleteSkill(id);
      setSkills(skills.filter(s => s.id !== id));
      toast.success('Skill deleted!');
    } catch (err) {
      toast.error('Failed to delete skill');
    }
  };

  const handleSave = async () => {
    if (!editingSkill.name || !editingSkill.proficiency) return;
    setSaving(true);
    try {
      if (editingSkill.id) {
        const updated = await contentService.updateSkill(editingSkill.id, editingSkill);
        setSkills(skills.map(s => s.id === updated.id ? updated : s));
        toast.success('Skill updated!');
      } else {
        const created = await contentService.createSkill(editingSkill as Omit<Skill, 'id' | 'created_at'>);
        setSkills([...skills, created]);
        toast.success('Skill created!');
      }
      setIsEditing(false);
      setEditingSkill({});
    } catch (err) {
      toast.error('Failed to save skill');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Skills Manager</h1>
            <p className="text-gray-500 mt-1">Manage your technical skills and expertise.</p>
          </div>
          <button onClick={handleCreate} className="btn-primary flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Add Skill
          </button>
        </div>
      </motion.div>

      {/* Skills Grid */}
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
        className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4"
      >
        {skills.map((skill) => (
          <motion.div key={skill.id} variants={fadeInUp}>
            <GlassCard className="group relative">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center">
                    <Code className="w-5 h-5 text-cyber-blue" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white">{skill.name}</h3>
                    <span className="text-xs text-gray-500 capitalize">{skill.category}</span>
                  </div>
                </div>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => handleEdit(skill)}
                    className="p-2 rounded-lg hover:bg-glass-medium text-gray-400 hover:text-cyber-blue transition-colors"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(skill.id)}
                    className="p-2 rounded-lg hover:bg-red-500/10 text-gray-400 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="mt-4">
                <div className="flex justify-between mb-1">
                  <span className="text-xs text-gray-500">Proficiency</span>
                  <span className="text-xs text-cyber-blue">{skill.proficiency}%</span>
                </div>
                <div className="h-2 bg-glass-light rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-cyber-blue to-cyber-purple rounded-full transition-all"
                    style={{ width: `${skill.proficiency}%` }}
                  />
                </div>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </motion.div>

      {skills.length === 0 && (
        <div className="text-center py-20">
          <Code className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-500">No skills added yet. Click "Add Skill" to get started.</p>
        </div>
      )}

      {/* Edit Modal */}
      <AnimatePresence>
        {isEditing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => setIsEditing(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-lg"
            >
              <GlassCard className="neon-border">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-white">
                    {editingSkill.id ? 'Edit Skill' : 'New Skill'}
                  </h2>
                  <button
                    onClick={() => setIsEditing(false)}
                    className="p-2 rounded-lg hover:bg-glass-medium text-gray-400"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Name</label>
                    <input
                      type="text"
                      value={editingSkill.name || ''}
                      onChange={(e) => setEditingSkill({ ...editingSkill, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                      placeholder="e.g. React.js"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Category</label>
                      <select
                        value={editingSkill.category || 'frontend'}
                        onChange={(e) => setEditingSkill({ ...editingSkill, category: e.target.value as Skill['category'] })}
                        className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                      >
                        {categories.map(cat => (
                          <option key={cat.value} value={cat.value} className="bg-cyber-dark">{cat.label}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Proficiency (%)</label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={editingSkill.proficiency || 50}
                        onChange={(e) => setEditingSkill({ ...editingSkill, proficiency: parseInt(e.target.value) })}
                        className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Icon Key</label>
                    <input
                      type="text"
                      value={editingSkill.icon_key || 'code'}
                      onChange={(e) => setEditingSkill({ ...editingSkill, icon_key: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                      placeholder="e.g. react, node, figma"
                    />
                  </div>
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    onClick={() => setIsEditing(false)}
                    className="btn-secondary flex-1"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={saving}
                    className="btn-primary flex-1 flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {saving ? <LoadingSpinner size="sm" /> : <Save className="w-4 h-4" />}
                    Save
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
