import { useState } from 'react';
import { motion } from 'framer-motion';
import { Save, RotateCcw, Type, User, Sparkles } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { useContent } from '@/hooks/useContent';
import { contentService } from '@/services/contentService';
import { fadeInUp, staggerContainer } from '@/animations/variants';
import toast from 'react-hot-toast';

export function ContentManager() {
  const { hero, about, settings, setHero, setAbout, setSettings } = useContent();
  const [saving, setSaving] = useState(false);

  const [heroForm, setHeroForm] = useState({
    title: hero?.title || '',
    subtitle: hero?.subtitle || '',
    cta_primary: hero?.cta_primary || '',
    cta_secondary: hero?.cta_secondary || '',
  });

  const [aboutForm, setAboutForm] = useState({
    biography: about?.biography || '',
    experience_years: about?.experience_years || 0,
    location: about?.location || '',
  });

  const [settingsForm, setSettingsForm] = useState({
    site_name: settings?.site_name || '',
    site_title: settings?.site_title || '',
  });

  const handleSaveHero = async () => {
    if (!hero?.id) return;
    setSaving(true);
    try {
      const updated = await contentService.updateHeroSection(hero.id, heroForm);
      setHero(updated);
      toast.success('Hero section updated!');
    } catch (err) {
      toast.error('Failed to update hero section');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveAbout = async () => {
    if (!about?.id) return;
    setSaving(true);
    try {
      const updated = await contentService.updateAboutSection(about.id, aboutForm);
      setAbout(updated);
      toast.success('About section updated!');
    } catch (err) {
      toast.error('Failed to update about section');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveSettings = async () => {
    if (!settings?.id) return;
    setSaving(true);
    try {
      const updated = await contentService.updateSiteSettings(settings.id, settingsForm);
      setSettings(updated);
      toast.success('Site settings updated!');
    } catch (err) {
      toast.error('Failed to update settings');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl font-bold text-white">Content Manager</h1>
        <p className="text-gray-500 mt-1">Manage your portfolio content sections.</p>
      </motion.div>

      <motion.div variants={staggerContainer} initial="hidden" animate="visible" className="space-y-8">
        {/* Site Settings */}
        <motion.div variants={fadeInUp}>
          <GlassCard>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-cyber-blue" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Site Settings</h2>
                <p className="text-sm text-gray-500">Basic site configuration</p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Site Name</label>
                <input
                  type="text"
                  value={settingsForm.site_name}
                  onChange={(e) => setSettingsForm({ ...settingsForm, site_name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Site Title</label>
                <input
                  type="text"
                  value={settingsForm.site_title}
                  onChange={(e) => setSettingsForm({ ...settingsForm, site_title: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                />
              </div>
            </div>

            <button
              onClick={handleSaveSettings}
              disabled={saving}
              className="btn-primary flex items-center gap-2 disabled:opacity-50"
            >
              {saving ? <LoadingSpinner size="sm" /> : <Save className="w-4 h-4" />}
              Save Settings
            </button>
          </GlassCard>
        </motion.div>

        {/* Hero Section */}
        <motion.div variants={fadeInUp}>
          <GlassCard>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center">
                <Type className="w-5 h-5 text-cyber-blue" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Hero Section</h2>
                <p className="text-sm text-gray-500">Main landing page content</p>
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Title</label>
                <input
                  type="text"
                  value={heroForm.title}
                  onChange={(e) => setHeroForm({ ...heroForm, title: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Subtitle</label>
                <textarea
                  rows={2}
                  value={heroForm.subtitle}
                  onChange={(e) => setHeroForm({ ...heroForm, subtitle: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50 resize-none"
                />
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Primary CTA</label>
                  <input
                    type="text"
                    value={heroForm.cta_primary}
                    onChange={(e) => setHeroForm({ ...heroForm, cta_primary: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Secondary CTA</label>
                  <input
                    type="text"
                    value={heroForm.cta_secondary}
                    onChange={(e) => setHeroForm({ ...heroForm, cta_secondary: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                  />
                </div>
              </div>
            </div>

            <button
              onClick={handleSaveHero}
              disabled={saving}
              className="btn-primary flex items-center gap-2 disabled:opacity-50"
            >
              {saving ? <LoadingSpinner size="sm" /> : <Save className="w-4 h-4" />}
              Save Hero
            </button>
          </GlassCard>
        </motion.div>

        {/* About Section */}
        <motion.div variants={fadeInUp}>
          <GlassCard>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center">
                <User className="w-5 h-5 text-cyber-blue" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">About Section</h2>
                <p className="text-sm text-gray-500">Your personal information</p>
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Biography</label>
                <textarea
                  rows={5}
                  value={aboutForm.biography}
                  onChange={(e) => setAboutForm({ ...aboutForm, biography: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50 resize-none"
                />
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Experience (years)</label>
                  <input
                    type="number"
                    value={aboutForm.experience_years}
                    onChange={(e) => setAboutForm({ ...aboutForm, experience_years: parseInt(e.target.value) || 0 })}
                    className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Location</label>
                  <input
                    type="text"
                    value={aboutForm.location}
                    onChange={(e) => setAboutForm({ ...aboutForm, location: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                  />
                </div>
              </div>
            </div>

            <button
              onClick={handleSaveAbout}
              disabled={saving}
              className="btn-primary flex items-center gap-2 disabled:opacity-50"
            >
              {saving ? <LoadingSpinner size="sm" /> : <Save className="w-4 h-4" />}
              Save About
            </button>
          </GlassCard>
        </motion.div>
      </motion.div>
    </div>
  );
}
