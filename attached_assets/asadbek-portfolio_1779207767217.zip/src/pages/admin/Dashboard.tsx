import { motion } from 'framer-motion';
import { 
  FolderOpen, Code, Eye, TrendingUp, ArrowUpRight, Clock 
} from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { useContent } from '@/hooks/useContent';
import { fadeInUp, staggerContainer } from '@/animations/variants';
import { Link } from 'react-router-dom';

export function AdminDashboard() {
  const { projects, skills } = useContent();

  const stats = [
    { 
      label: 'Total Projects', 
      value: projects.length, 
      icon: FolderOpen, 
      color: 'from-cyber-blue to-cyan-500',
      link: '/admin/projects'
    },
    { 
      label: 'Skills', 
      value: skills.length, 
      icon: Code, 
      color: 'from-cyber-purple to-pink-500',
      link: '/admin/skills'
    },
    { 
      label: 'Featured', 
      value: projects.filter(p => p.featured).length, 
      icon: TrendingUp, 
      color: 'from-green-400 to-emerald-500',
      link: '/admin/projects'
    },
    { 
      label: 'Total Views', 
      value: '1.2K', 
      icon: Eye, 
      color: 'from-orange-400 to-red-500',
      link: '#'
    },
  ];

  const recentProjects = projects.slice(0, 5);

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-white">Dashboard</h1>
        <p className="text-gray-500 mt-1">Welcome back, here's what's happening with your portfolio.</p>
      </motion.div>

      {/* Stats Grid */}
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
        className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
      >
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <motion.div key={i} variants={fadeInUp}>
              <Link to={stat.link}>
                <GlassCard className="group cursor-pointer">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm text-gray-500">{stat.label}</p>
                      <p className="text-3xl font-bold text-white mt-1">{stat.value}</p>
                    </div>
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                  </div>
                  <div className="flex items-center gap-1 mt-4 text-sm text-cyber-blue opacity-0 group-hover:opacity-100 transition-opacity">
                    <span>View details</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </GlassCard>
              </Link>
            </motion.div>
          );
        })}
      </motion.div>

      {/* Recent Projects */}
      <motion.div
        variants={fadeInUp}
        initial="hidden"
        animate="visible"
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white">Recent Projects</h2>
          <Link to="/admin/projects" className="text-sm text-cyber-blue hover:underline">
            View All
          </Link>
        </div>

        <GlassCard className="overflow-hidden p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-glass-border">
                  <th className="text-left px-6 py-4 text-sm font-medium text-gray-500">Project</th>
                  <th className="text-left px-6 py-4 text-sm font-medium text-gray-500">Status</th>
                  <th className="text-left px-6 py-4 text-sm font-medium text-gray-500">Date</th>
                  <th className="text-right px-6 py-4 text-sm font-medium text-gray-500">Actions</th>
                </tr>
              </thead>
              <tbody>
                {recentProjects.map((project) => (
                  <tr key={project.id} className="border-b border-glass-border/50 hover:bg-glass-light/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center">
                          <FolderOpen className="w-5 h-5 text-cyber-blue" />
                        </div>
                        <div>
                          <p className="font-medium text-white">{project.title}</p>
                          <p className="text-xs text-gray-500">{project.slug}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        project.featured 
                          ? 'bg-green-500/10 text-green-400 border border-green-500/20' 
                          : 'bg-gray-500/10 text-gray-400 border border-gray-500/20'
                      }`}>
                        {project.featured ? 'Featured' : 'Standard'}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1 text-sm text-gray-500">
                        <Clock className="w-4 h-4" />
                        {new Date(project.created_at).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <Link 
                        to={`/admin/projects?edit=${project.id}`}
                        className="text-cyber-blue hover:underline text-sm"
                      >
                        Edit
                      </Link>
                    </td>
                  </tr>
                ))}
                {recentProjects.length === 0 && (
                  <tr>
                    <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                      No projects yet. Create your first project to get started.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </GlassCard>
      </motion.div>
    </div>
  );
}
