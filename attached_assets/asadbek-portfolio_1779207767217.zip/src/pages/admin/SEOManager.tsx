import { useState } from 'react';
import { motion } from 'framer-motion';
import { Save, Search, Tag, Image } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { useContent } from '@/hooks/useContent';
import { contentService } from '@/services/contentService';
import { storageService } from '@/services/storageService';
import { fadeInUp } from '@/animations/variants';
import toast from 'react-hot-toast';

export function SEOManager() {
  const { seo, setSEO } = useContent();
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const [form, setForm] = useState({
    meta_title: seo?.meta_title || '',
    meta_description: seo?.meta_description || '',
    keywords: seo?.keywords || '',
    og_image_url: seo?.og_image_url || '',
  });

  const handleSave = async () => {
    if (!seo?.id) return;
    setSaving(true);
    try {
      const updated = await contentService.updateSEOSettings(seo.id, form);
      setSEO(updated);
      toast.success('SEO settings updated!');
    } catch (err) {
      toast.error('Failed to update SEO');
    } finally {
      setSaving(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const url = await storageService.uploadImage(file, 'seo');
      setForm({ ...form, og_image_url: url });
      toast.success('OG image uploaded!');
    } catch (err) {
      toast.error('Upload failed');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div>
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl font-bold text-white">SEO Settings</h1>
        <p className="text-gray-500 mt-1">Optimize your portfolio for search engines.</p>
      </motion.div>

      <motion.div variants={fadeInUp} initial="hidden" animate="visible">
        <GlassCard>
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                <Search className="w-4 h-4 text-cyber-blue" />
                Meta Title
              </label>
              <input
                type="text"
                value={form.meta_title}
                onChange={(e) => setForm({ ...form, meta_title: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                placeholder="Asadbek Komilov | Creative Developer"
              />
              <p className="text-xs text-gray-500 mt-1">Recommended: 50-60 characters</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                <Search className="w-4 h-4 text-cyber-blue" />
                Meta Description
              </label>
              <textarea
                rows={3}
                value={form.meta_description}
                onChange={(e) => setForm({ ...form, meta_description: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50 resize-none"
                placeholder="Brief description of your portfolio..."
              />
              <p className="text-xs text-gray-500 mt-1">Recommended: 150-160 characters</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                <Tag className="w-4 h-4 text-cyber-blue" />
                Keywords
              </label>
              <input
                type="text"
                value={form.keywords}
                onChange={(e) => setForm({ ...form, keywords: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                placeholder="web developer, react, portfolio, ..."
              />
              <p className="text-xs text-gray-500 mt-1">Comma-separated keywords</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                <Image className="w-4 h-4 text-cyber-blue" />
                OG Image (Social Share)
              </label>
              <div className="flex items-center gap-4">
                {form.og_image_url && (
                  <img src={form.og_image_url} alt="OG Preview" className="w-32 h-20 rounded-xl object-cover" />
                )}
                <label className="flex-1">
                  <div className="px-4 py-3 rounded-xl bg-glass-light border border-dashed border-glass-border text-gray-400 hover:text-white hover:border-cyber-blue/50 transition-colors cursor-pointer text-center">
                    {uploading ? <LoadingSpinner size="sm" /> : 'Upload OG Image'}
                  </div>
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </label>
              </div>
            </div>

            <button
              onClick={handleSave}
              disabled={saving}
              className="btn-primary flex items-center gap-2 disabled:opacity-50"
            >
              {saving ? <LoadingSpinner size="sm" /> : <Save className="w-4 h-4" />}
              Save SEO Settings
            </button>
          </div>
        </GlassCard>
      </motion.div>
    </div>
  );
}
