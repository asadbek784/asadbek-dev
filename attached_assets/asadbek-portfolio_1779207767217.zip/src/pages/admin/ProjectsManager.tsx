import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Pencil, Trash2, X, Save, Image, ExternalLink, Github, Star } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { useContent } from '@/hooks/useContent';
import { contentService } from '@/services/contentService';
import { storageService } from '@/services/storageService';
import { fadeInUp, staggerContainer } from '@/animations/variants';
import type { Project } from '@/types';
import toast from 'react-hot-toast';

export function ProjectsManager() {
  const { projects, setProjects } = useContent();
  const [isEditing, setIsEditing] = useState(false);
  const [editingProject, setEditingProject] = useState<Partial<Project>>({});
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleCreate = () => {
    setEditingProject({
      title: '',
      slug: '',
      short_description: '',
      full_description: '',
      featured: false,
      github_url: '',
      live_url: '',
    });
    setIsEditing(true);
  };

  const handleEdit = (project: Project) => {
    setEditingProject({ ...project });
    setIsEditing(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this project?')) return;
    try {
      await contentService.deleteProject(id);
      setProjects(projects.filter(p => p.id !== id));
      toast.success('Project deleted!');
    } catch (err) {
      toast.error('Failed to delete project');
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const url = await storageService.uploadImage(file);
      setEditingProject({ ...editingProject, thumbnail_url: url });
      toast.success('Image uploaded!');
    } catch (err) {
      toast.error('Failed to upload image');
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    if (!editingProject.title || !editingProject.slug) return;
    setSaving(true);
    try {
      if (editingProject.id) {
        const updated = await contentService.updateProject(editingProject.id, editingProject);
        setProjects(projects.map(p => p.id === updated.id ? updated : p));
        toast.success('Project updated!');
      } else {
        const created = await contentService.createProject(editingProject as Omit<Project, 'id' | 'created_at'>);
        setProjects([created, ...projects]);
        toast.success('Project created!');
      }
      setIsEditing(false);
      setEditingProject({});
    } catch (err) {
      toast.error('Failed to save project');
    } finally {
      setSaving(false);
    }
  };

  const generateSlug = (title: string) => {
    return title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  return (
    <div>
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Projects Manager</h1>
            <p className="text-gray-500 mt-1">Manage your portfolio projects.</p>
          </div>
          <button onClick={handleCreate} className="btn-primary flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Add Project
          </button>
        </div>
      </motion.div>

      {/* Projects List */}
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
        className="space-y-4"
      >
        {projects.map((project) => (
          <motion.div key={project.id} variants={fadeInUp}>
            <GlassCard className="group">
              <div className="flex items-start gap-4">
                <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0 bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20">
                  {project.thumbnail_url ? (
                    <img src={project.thumbnail_url} alt={project.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Image className="w-8 h-8 text-cyber-blue/50" />
                    </div>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-white">{project.title}</h3>
                        {project.featured && (
                          <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                        )}
                      </div>
                      <p className="text-xs text-gray-500 mt-1">/{project.slug}</p>
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => handleEdit(project)}
                        className="p-2 rounded-lg hover:bg-glass-medium text-gray-400 hover:text-cyber-blue transition-colors"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(project.id)}
                        className="p-2 rounded-lg hover:bg-red-500/10 text-gray-400 hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <p className="text-sm text-gray-400 mt-2 line-clamp-2">{project.short_description}</p>

                  <div className="flex items-center gap-3 mt-3">
                    {project.github_url && (
                      <a href={project.github_url} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-white">
                        <Github className="w-4 h-4" />
                      </a>
                    )}
                    {project.live_url && (
                      <a href={project.live_url} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-white">
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </motion.div>

      {projects.length === 0 && (
        <div className="text-center py-20">
          <Image className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-500">No projects yet. Click "Add Project" to get started.</p>
        </div>
      )}

      {/* Edit Modal */}
      <AnimatePresence>
        {isEditing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto"
            onClick={() => setIsEditing(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-2xl my-8"
            >
              <GlassCard className="neon-border">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-white">
                    {editingProject.id ? 'Edit Project' : 'New Project'}
                  </h2>
                  <button
                    onClick={() => setIsEditing(false)}
                    className="p-2 rounded-lg hover:bg-glass-medium text-gray-400"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Title</label>
                      <input
                        type="text"
                        value={editingProject.title || ''}
                        onChange={(e) => {
                          const title = e.target.value;
                          setEditingProject({
                            ...editingProject,
                            title,
                            slug: editingProject.slug || generateSlug(title),
                          });
                        }}
                        className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Slug</label>
                      <input
                        type="text"
                        value={editingProject.slug || ''}
                        onChange={(e) => setEditingProject({ ...editingProject, slug: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Short Description</label>
                    <input
                      type="text"
                      value={editingProject.short_description || ''}
                      onChange={(e) => setEditingProject({ ...editingProject, short_description: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Full Description</label>
                    <textarea
                      rows={4}
                      value={editingProject.full_description || ''}
                      onChange={(e) => setEditingProject({ ...editingProject, full_description: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50 resize-none"
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">GitHub URL</label>
                      <input
                        type="url"
                        value={editingProject.github_url || ''}
                        onChange={(e) => setEditingProject({ ...editingProject, github_url: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Live URL</label>
                      <input
                        type="url"
                        value={editingProject.live_url || ''}
                        onChange={(e) => setEditingProject({ ...editingProject, live_url: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white focus:outline-none focus:border-cyber-blue/50"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Thumbnail</label>
                    <div className="flex items-center gap-4">
                      {editingProject.thumbnail_url && (
                        <img src={editingProject.thumbnail_url} alt="Preview" className="w-20 h-20 rounded-xl object-cover" />
                      )}
                      <label className="flex-1">
                        <div className="px-4 py-3 rounded-xl bg-glass-light border border-dashed border-glass-border text-gray-400 hover:text-white hover:border-cyber-blue/50 transition-colors cursor-pointer text-center">
                          {uploading ? <LoadingSpinner size="sm" /> : 'Click to upload image'}
                        </div>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="featured"
                      checked={editingProject.featured || false}
                      onChange={(e) => setEditingProject({ ...editingProject, featured: e.target.checked })}
                      className="w-4 h-4 rounded border-glass-border bg-glass-light text-cyber-blue focus:ring-cyber-blue"
                    />
                    <label htmlFor="featured" className="text-sm text-gray-300">Featured Project</label>
                  </div>
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    onClick={() => setIsEditing(false)}
                    className="btn-secondary flex-1"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={saving}
                    className="btn-primary flex-1 flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {saving ? <LoadingSpinner size="sm" /> : <Save className="w-4 h-4" />}
                    Save
                  </button>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
