import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, MapPin, Send, Github, Linkedin, Twitter, Globe, CheckCircle } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { SectionTitle } from '@/components/ui/SectionTitle';
import { useContent } from '@/hooks/useContent';
import { fadeInUp, staggerContainer } from '@/animations/variants';

const socialIcons: Record<string, React.ReactNode> = {
  github: <Github className="w-6 h-6" />,
  linkedin: <Linkedin className="w-6 h-6" />,
  twitter: <Twitter className="w-6 h-6" />,
  website: <Globe className="w-6 h-6" />,
  email: <Mail className="w-6 h-6" />,
};

export function Contact() {
  const { socialLinks, about } = useContent();
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In production, integrate with Supabase or email service
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className="pt-20">
      <section className="section-padding py-16 max-w-7xl mx-auto">
        <SectionTitle 
          title="Get In Touch" 
          subtitle="Have a project in mind? Let's work together to create something amazing."
        />

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="space-y-6"
          >
            <motion.div variants={fadeInUp}>
              <h2 className="text-2xl font-bold text-white mb-6">Let's Talk</h2>
              <p className="text-gray-400 leading-relaxed mb-8">
                I'm always interested in hearing about new projects and opportunities. 
                Whether you have a question or just want to say hi, feel free to reach out!
              </p>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <GlassCard className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center">
                  <Mail className="w-6 h-6 text-cyber-blue" />
                </div>
                <div>
                  <div className="text-sm text-gray-500">Email</div>
                  <a href="mailto:hello@asadbek.dev" className="text-white hover:text-cyber-blue transition-colors">
                    hello@asadbek.dev
                  </a>
                </div>
              </GlassCard>
            </motion.div>

            {about?.location && (
              <motion.div variants={fadeInUp}>
                <GlassCard className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-cyber-blue" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Location</div>
                    <span className="text-white">{about.location}</span>
                  </div>
                </GlassCard>
              </motion.div>
            )}

            {/* Social Links */}
            <motion.div variants={fadeInUp}>
              <h3 className="font-bold text-white mb-4">Connect With Me</h3>
              <div className="flex gap-3">
                {socialLinks.map((link) => (
                  <a
                    key={link.id}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 rounded-xl glass-card flex items-center justify-center text-gray-400 hover:text-cyber-blue hover:border-cyber-blue/30 transition-all"
                  >
                    {socialIcons[link.icon_key] || <Globe className="w-6 h-6" />}
                  </a>
                ))}
              </div>
            </motion.div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <GlassCard className="h-full">
              {submitted ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-12">
                  <CheckCircle className="w-16 h-16 text-green-400 mb-4" />
                  <h3 className="text-xl font-bold text-white mb-2">Message Sent!</h3>
                  <p className="text-gray-400">Thank you for reaching out. I'll get back to you soon.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Name</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white placeholder-gray-500 focus:outline-none focus:border-cyber-blue/50 transition-colors"
                      placeholder="Your name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white placeholder-gray-500 focus:outline-none focus:border-cyber-blue/50 transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Message</label>
                    <textarea
                      required
                      rows={5}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-glass-light border border-glass-border text-white placeholder-gray-500 focus:outline-none focus:border-cyber-blue/50 transition-colors resize-none"
                      placeholder="Tell me about your project..."
                    />
                  </div>

                  <button type="submit" className="btn-primary w-full flex items-center justify-center gap-2">
                    <Send className="w-4 h-4" />
                    Send Message
                  </button>
                </form>
              )}
            </GlassCard>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
