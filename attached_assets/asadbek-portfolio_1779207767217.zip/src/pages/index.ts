export { Home } from './Home';
export { About } from './About';
export { Projects } from './Projects';
export { ProjectDetail } from './ProjectDetail';
export { Contact } from './Contact';
