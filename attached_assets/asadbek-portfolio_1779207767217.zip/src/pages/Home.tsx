import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles, Code2, Palette, Zap } from 'lucide-react';
import { Scene3D } from '@/components/3d/Scene';
import { GlassCard } from '@/components/ui/GlassCard';
import { SectionTitle } from '@/components/ui/SectionTitle';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { useContent } from '@/hooks/useContent';
import { fadeInUp, staggerContainer, scaleIn } from '@/animations/variants';

export function Home() {
  const { hero, about, skills, projects, loading } = useContent();

  const featuredProjects = projects.filter(p => p.featured).slice(0, 3);
  const topSkills = skills.slice(0, 6);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <Scene3D />

        <div className="relative z-10 section-padding max-w-7xl mx-auto text-center">
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
            className="space-y-6"
          >
            <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card text-sm text-cyber-blue mb-4">
              <Sparkles className="w-4 h-4" />
              <span>Creative Developer & Designer</span>
            </motion.div>

            <motion.h1 
              variants={fadeInUp}
              className="text-5xl md:text-7xl lg:text-8xl font-bold leading-tight"
            >
              <span className="text-white">Crafting</span>
              <br />
              <span className="text-gradient">Digital Experiences</span>
            </motion.h1>

            <motion.p 
              variants={fadeInUp}
              className="text-xl md:text-2xl text-gray-400 max-w-2xl mx-auto"
            >
              {hero?.subtitle || 'Building immersive web experiences with cutting-edge technology and stunning design.'}
            </motion.p>

            <motion.div 
              variants={fadeInUp}
              className="flex flex-col sm:flex-row gap-4 justify-center mt-8"
            >
              <Link to="/projects" className="btn-primary inline-flex items-center gap-2">
                {hero?.cta_primary || 'View Projects'}
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link to="/about" className="btn-secondary inline-flex items-center gap-2">
                {hero?.cta_secondary || 'About Me'}
              </Link>
            </motion.div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.8 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-20 max-w-3xl mx-auto"
          >
            {[
              { value: about?.experience_years || '5+', label: 'Years Experience' },
              { value: projects.length.toString(), label: 'Projects Completed' },
              { value: skills.length.toString(), label: 'Technologies' },
              { value: '50+', label: 'Happy Clients' },
            ].map((stat, i) => (
              <div key={i} className="glass-card p-4 text-center">
                <div className="text-2xl md:text-3xl font-bold text-gradient">{stat.value}</div>
                <div className="text-xs text-gray-500 mt-1">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-6 h-10 rounded-full border-2 border-cyber-blue/30 flex justify-center pt-2"
          >
            <div className="w-1.5 h-1.5 rounded-full bg-cyber-blue" />
          </motion.div>
        </motion.div>
      </section>

      {/* Skills Section */}
      <section className="section-padding py-24 max-w-7xl mx-auto">
        <SectionTitle 
          title="Technical Skills" 
          subtitle="Technologies and tools I use to bring ideas to life"
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4"
        >
          {topSkills.map((skill, i) => (
            <motion.div key={skill.id} variants={scaleIn}>
              <GlassCard className="text-center p-6 hover:scale-105 transition-transform">
                <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center">
                  <Code2 className="w-6 h-6 text-cyber-blue" />
                </div>
                <h3 className="font-semibold text-sm text-white">{skill.name}</h3>
                <div className="mt-2 h-1.5 bg-glass-light rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${skill.proficiency}%` }}
                    transition={{ duration: 1, delay: i * 0.1 }}
                    viewport={{ once: true }}
                    className="h-full bg-gradient-to-r from-cyber-blue to-cyber-purple rounded-full"
                  />
                </div>
                <span className="text-xs text-gray-500 mt-1">{skill.proficiency}%</span>
              </GlassCard>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Featured Projects */}
      <section className="section-padding py-24 max-w-7xl mx-auto">
        <SectionTitle 
          title="Featured Projects" 
          subtitle="Some of my recent work that I'm proud of"
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {featuredProjects.map((project) => (
            <motion.div key={project.id} variants={fadeInUp}>
              <Link to={`/projects/${project.slug}`}>
                <GlassCard className="group overflow-hidden p-0">
                  <div className="relative aspect-video overflow-hidden">
                    {project.thumbnail_url ? (
                      <img 
                        src={project.thumbnail_url} 
                        alt={project.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center">
                        <Palette className="w-12 h-12 text-cyber-blue/50" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-cyber-dark via-transparent to-transparent opacity-60" />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white group-hover:text-cyber-blue transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-gray-400 text-sm mt-2 line-clamp-2">
                      {project.short_description}
                    </p>
                    <div className="flex items-center gap-2 mt-4 text-cyber-blue text-sm font-medium">
                      <span>View Project</span>
                      <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                </GlassCard>
              </Link>
            </motion.div>
          ))}
        </motion.div>

        <div className="text-center mt-12">
          <Link to="/projects" className="btn-secondary inline-flex items-center gap-2">
            View All Projects
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding py-24">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto text-center glass-card-strong p-12 md:p-16 neon-border"
        >
          <Zap className="w-12 h-12 text-cyber-blue mx-auto mb-6" />
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Build Something Amazing?
          </h2>
          <p className="text-gray-400 text-lg mb-8 max-w-xl mx-auto">
            Let's collaborate and create something extraordinary together. I'm always open to new opportunities.
          </p>
          <Link to="/contact" className="btn-primary inline-flex items-center gap-2">
            Get In Touch
            <ArrowRight className="w-4 h-4" />
          </Link>
        </motion.div>
      </section>
    </div>
  );
}
