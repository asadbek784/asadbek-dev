import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, ExternalLink, Github, Calendar, Tag } from 'lucide-react';
import { GlassCard } from '@/components/ui/GlassCard';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { contentService } from '@/services/contentService';
import type { Project } from '@/types';
import { fadeInUp, staggerContainer } from '@/animations/variants';

export function ProjectDetail() {
  const { slug } = useParams<{ slug: string }>();
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProject = async () => {
      if (!slug) return;
      try {
        const data = await contentService.getProjectBySlug(slug);
        setProject(data);
      } catch (err) {
        setError((err as Error).message);
      } finally {
        setLoading(false);
      }
    };
    fetchProject();
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (error || !project) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <GlassCard className="text-center p-8">
          <h2 className="text-xl font-bold text-red-400 mb-2">Project Not Found</h2>
          <p className="text-gray-400 mb-4">The project you're looking for doesn't exist.</p>
          <Link to="/projects" className="btn-primary inline-flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back to Projects
          </Link>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="pt-20">
      <section className="section-padding py-16 max-w-5xl mx-auto">
        {/* Back Button */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-8"
        >
          <Link 
            to="/projects" 
            className="inline-flex items-center gap-2 text-gray-400 hover:text-cyber-blue transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Projects</span>
          </Link>
        </motion.div>

        {/* Project Header */}
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate="visible"
          className="mb-12"
        >
          <motion.h1 
            variants={fadeInUp}
            className="text-4xl md:text-5xl font-bold text-white mb-4"
          >
            {project.title}
          </motion.h1>

          <motion.div 
            variants={fadeInUp}
            className="flex flex-wrap items-center gap-4 text-sm text-gray-400"
          >
            <div className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              <span>{new Date(project.created_at).toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long' 
              })}</span>
            </div>
            {project.featured && (
              <div className="px-3 py-1 rounded-full bg-gradient-to-r from-cyber-blue to-cyber-purple text-xs font-bold text-white">
                Featured Project
              </div>
            )}
          </motion.div>
        </motion.div>

        {/* Main Image */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-12"
        >
          <GlassCard className="overflow-hidden p-0">
            {project.thumbnail_url ? (
              <img 
                src={project.thumbnail_url} 
                alt={project.title}
                className="w-full aspect-video object-cover"
              />
            ) : (
              <div className="w-full aspect-video bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center">
                <Tag className="w-16 h-16 text-cyber-blue/50" />
              </div>
            )}
          </GlassCard>
        </motion.div>

        {/* Project Info */}
        <div className="grid lg:grid-cols-3 gap-8">
          <motion.div 
            variants={fadeInUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="lg:col-span-2 space-y-6"
          >
            <div>
              <h2 className="text-2xl font-bold text-white mb-4">About This Project</h2>
              <div className="prose prose-invert max-w-none">
                <p className="text-gray-300 leading-relaxed whitespace-pre-wrap">
                  {project.full_description || project.short_description}
                </p>
              </div>
            </div>

            {/* Project Images Gallery */}
            {project.images && project.images.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-white mb-4">Gallery</h2>
                <div className="grid grid-cols-2 gap-4">
                  {project.images.map((image) => (
                    <GlassCard key={image.id} className="overflow-hidden p-0">
                      <img 
                        src={image.image_url} 
                        alt={`${project.title} screenshot`}
                        className="w-full aspect-video object-cover hover:scale-105 transition-transform duration-500"
                      />
                    </GlassCard>
                  ))}
                </div>
              </div>
            )}
          </motion.div>

          {/* Sidebar */}
          <motion.div
            variants={fadeInUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="space-y-6"
          >
            <GlassCard>
              <h3 className="font-bold text-white mb-4">Project Links</h3>
              <div className="space-y-3">
                {project.live_url && (
                  <a 
                    href={project.live_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-3 rounded-xl bg-glass-light hover:bg-glass-medium transition-colors"
                  >
                    <ExternalLink className="w-5 h-5 text-cyber-blue" />
                    <div>
                      <div className="text-sm font-medium text-white">Live Demo</div>
                      <div className="text-xs text-gray-500">View the live project</div>
                    </div>
                  </a>
                )}

                {project.github_url && (
                  <a 
                    href={project.github_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-3 rounded-xl bg-glass-light hover:bg-glass-medium transition-colors"
                  >
                    <Github className="w-5 h-5 text-cyber-purple" />
                    <div>
                      <div className="text-sm font-medium text-white">Source Code</div>
                      <div className="text-xs text-gray-500">View on GitHub</div>
                    </div>
                  </a>
                )}
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
