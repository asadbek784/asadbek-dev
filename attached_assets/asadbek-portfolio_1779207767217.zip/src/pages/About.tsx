import { motion } from 'framer-motion';
import { MapPin, Calendar, Award, BookOpen, Briefcase, GraduationCap } from 'lucide-react';
import { SectionTitle } from '@/components/ui/SectionTitle';
import { GlassCard } from '@/components/ui/GlassCard';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { useContent } from '@/hooks/useContent';
import { fadeInUp, staggerContainer, slideInLeft, slideInRight } from '@/animations/variants';

export function About() {
  const { about, skills, loading } = useContent();

  const categories = ['frontend', 'backend', 'design', 'tools'] as const;

  const categoryLabels: Record<string, string> = {
    frontend: 'Frontend Development',
    backend: 'Backend Development',
    design: 'UI/UX Design',
    tools: 'Tools & DevOps',
  };

  const categoryIcons: Record<string, React.ReactNode> = {
    frontend: <Briefcase className="w-5 h-5" />,
    backend: <BookOpen className="w-5 h-5" />,
    design: <Award className="w-5 h-5" />,
    tools: <GraduationCap className="w-5 h-5" />,
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="pt-20">
      {/* Hero About */}
      <section className="section-padding py-16 max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            variants={slideInLeft}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <div className="relative">
              <div className="aspect-square max-w-md mx-auto lg:mx-0 rounded-3xl overflow-hidden glass-card-strong neon-border">
                {about?.profile_image ? (
                  <img 
                    src={about.profile_image} 
                    alt="Asadbek Komilov"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center">
                    <span className="text-6xl font-bold text-gradient">AK</span>
                  </div>
                )}
              </div>
              <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-gradient-to-br from-cyber-blue to-cyber-purple rounded-2xl flex items-center justify-center glass-card">
                <span className="text-2xl font-bold text-white">{about?.experience_years || '5'}+</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            variants={slideInRight}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="space-y-6"
          >
            <h1 className="text-4xl md:text-5xl font-bold">
              <span className="text-gradient">About Me</span>
            </h1>

            <div className="flex flex-wrap gap-4 text-sm text-gray-400">
              {about?.location && (
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-cyber-blue" />
                  <span>{about.location}</span>
                </div>
              )}
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-cyber-blue" />
                <span>{about?.experience_years || '5'}+ Years Experience</span>
              </div>
            </div>

            <div className="prose prose-invert max-w-none">
              <p className="text-gray-300 leading-relaxed text-lg">
                {about?.biography || 
                  "I'm a passionate full-stack developer with a strong focus on creating beautiful, functional, and user-friendly web applications. With expertise in modern frontend frameworks, backend technologies, and cloud infrastructure, I bring ideas to life with clean code and stunning design."}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {[
                { label: 'Projects Completed', value: '50+' },
                { label: 'Happy Clients', value: '30+' },
                { label: 'Awards Won', value: '5+' },
                { label: 'Coffee Consumed', value: '∞' },
              ].map((stat, i) => (
                <GlassCard key={i} className="text-center p-4">
                  <div className="text-2xl font-bold text-gradient">{stat.value}</div>
                  <div className="text-xs text-gray-500">{stat.label}</div>
                </GlassCard>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Skills by Category */}
      <section className="section-padding py-16 max-w-7xl mx-auto">
        <SectionTitle 
          title="My Expertise" 
          subtitle="A breakdown of my technical capabilities across different domains"
        />

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid md:grid-cols-2 gap-6"
        >
          {categories.map((category) => {
            const categorySkills = skills.filter(s => s.category === category);
            if (categorySkills.length === 0) return null;

            return (
              <motion.div key={category} variants={fadeInUp}>
                <GlassCard className="h-full">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyber-blue/20 to-cyber-purple/20 flex items-center justify-center text-cyber-blue">
                      {categoryIcons[category]}
                    </div>
                    <h3 className="font-bold text-lg text-white">{categoryLabels[category]}</h3>
                  </div>

                  <div className="space-y-4">
                    {categorySkills.map((skill) => (
                      <div key={skill.id}>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm text-gray-300">{skill.name}</span>
                          <span className="text-sm text-cyber-blue">{skill.proficiency}%</span>
                        </div>
                        <div className="h-2 bg-glass-light rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            whileInView={{ width: `${skill.proficiency}%` }}
                            transition={{ duration: 1 }}
                            viewport={{ once: true }}
                            className="h-full bg-gradient-to-r from-cyber-blue to-cyber-purple rounded-full"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </GlassCard>
              </motion.div>
            );
          })}
        </motion.div>
      </section>
    </div>
  );
}
