import { supabase } from '@/lib/supabase';

export const storageService = {
  async uploadImage(file: File, bucket: string = 'portfolio'): Promise<string> {
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
    const filePath = `${bucket}/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('portfolio-assets')
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false,
      });

    if (uploadError) throw uploadError;

    const { data } = supabase.storage.from('portfolio-assets').getPublicUrl(filePath);
    return data.publicUrl;
  },

  async deleteImage(url: string): Promise<void> {
    const path = url.split('/').slice(-2).join('/');
    const { error } = await supabase.storage.from('portfolio-assets').remove([path]);
    if (error) throw error;
  },
};
