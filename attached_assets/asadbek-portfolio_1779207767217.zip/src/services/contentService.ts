import { supabase } from '@/lib/supabase';
import type { 
  SiteSettings, HeroSection, AboutSection, 
  Skill, Project, SocialLink, SEOSettings 
} from '@/types';

export const contentService = {
  async getSiteSettings(): Promise<SiteSettings | null> {
    const { data, error } = await supabase
      .from('site_settings')
      .select('*')
      .single();
    if (error) throw error;
    return data;
  },

  async updateSiteSettings(id: string, settings: Partial<SiteSettings>) {
    const { data, error } = await supabase
      .from('site_settings')
      .update(settings)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async getHeroSection(): Promise<HeroSection | null> {
    const { data, error } = await supabase
      .from('hero_section')
      .select('*')
      .single();
    if (error) throw error;
    return data;
  },

  async updateHeroSection(id: string, hero: Partial<HeroSection>) {
    const { data, error } = await supabase
      .from('hero_section')
      .update(hero)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async getAboutSection(): Promise<AboutSection | null> {
    const { data, error } = await supabase
      .from('about_section')
      .select('*')
      .single();
    if (error) throw error;
    return data;
  },

  async updateAboutSection(id: string, about: Partial<AboutSection>) {
    const { data, error } = await supabase
      .from('about_section')
      .update(about)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async getSkills(): Promise<Skill[]> {
    const { data, error } = await supabase
      .from('skills')
      .select('*')
      .order('created_at', { ascending: true });
    if (error) throw error;
    return data || [];
  },

  async createSkill(skill: Omit<Skill, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('skills')
      .insert(skill)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async updateSkill(id: string, skill: Partial<Skill>) {
    const { data, error } = await supabase
      .from('skills')
      .update(skill)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async deleteSkill(id: string) {
    const { error } = await supabase.from('skills').delete().eq('id', id);
    if (error) throw error;
  },

  async getProjects(): Promise<Project[]> {
    const { data, error } = await supabase
      .from('projects')
      .select('*, images:project_images(*)')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async getFeaturedProjects(): Promise<Project[]> {
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .eq('featured', true)
      .order('created_at', { ascending: false })
      .limit(6);
    if (error) throw error;
    return data || [];
  },

  async getProjectBySlug(slug: string): Promise<Project | null> {
    const { data, error } = await supabase
      .from('projects')
      .select('*, images:project_images(*)')
      .eq('slug', slug)
      .single();
    if (error) throw error;
    return data;
  },

  async createProject(project: Omit<Project, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('projects')
      .insert(project)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async updateProject(id: string, project: Partial<Project>) {
    const { data, error } = await supabase
      .from('projects')
      .update(project)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async deleteProject(id: string) {
    const { error } = await supabase.from('projects').delete().eq('id', id);
    if (error) throw error;
  },

  async getSocialLinks(): Promise<SocialLink[]> {
    const { data, error } = await supabase
      .from('social_links')
      .select('*')
      .eq('visible', true)
      .order('sort_order', { ascending: true });
    if (error) throw error;
    return data || [];
  },

  async getAllSocialLinks(): Promise<SocialLink[]> {
    const { data, error } = await supabase
      .from('social_links')
      .select('*')
      .order('sort_order', { ascending: true });
    if (error) throw error;
    return data || [];
  },

  async createSocialLink(link: Omit<SocialLink, 'id'>) {
    const { data, error } = await supabase
      .from('social_links')
      .insert(link)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async updateSocialLink(id: string, link: Partial<SocialLink>) {
    const { data, error } = await supabase
      .from('social_links')
      .update(link)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async deleteSocialLink(id: string) {
    const { error } = await supabase.from('social_links').delete().eq('id', id);
    if (error) throw error;
  },

  async getSEOSettings(): Promise<SEOSettings | null> {
    const { data, error } = await supabase
      .from('seo_settings')
      .select('*')
      .single();
    if (error) throw error;
    return data;
  },

  async updateSEOSettings(id: string, seo: Partial<SEOSettings>) {
    const { data, error } = await supabase
      .from('seo_settings')
      .update(seo)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },
};
