import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { Suspense, lazy } from 'react';
import { MainLayout } from '@/layouts/MainLayout';
import { AdminLayout } from '@/layouts/AdminLayout';
import { ErrorBoundary } from '@/components/ui/ErrorBoundary';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';

// Lazy load pages for performance
const Home = lazy(() => import('@/pages/Home').then(m => ({ default: m.Home })));
const About = lazy(() => import('@/pages/About').then(m => ({ default: m.About })));
const Projects = lazy(() => import('@/pages/Projects').then(m => ({ default: m.Projects })));
const ProjectDetail = lazy(() => import('@/pages/ProjectDetail').then(m => ({ default: m.ProjectDetail })));
const Contact = lazy(() => import('@/pages/Contact').then(m => ({ default: m.Contact })));

// Admin pages
const AdminLogin = lazy(() => import('@/pages/admin/Login').then(m => ({ default: m.AdminLogin })));
const AdminDashboard = lazy(() => import('@/pages/admin/Dashboard').then(m => ({ default: m.AdminDashboard })));
const ContentManager = lazy(() => import('@/pages/admin/ContentManager').then(m => ({ default: m.ContentManager })));
const SkillsManager = lazy(() => import('@/pages/admin/SkillsManager').then(m => ({ default: m.SkillsManager })));
const ProjectsManager = lazy(() => import('@/pages/admin/ProjectsManager').then(m => ({ default: m.ProjectsManager })));
const SocialManager = lazy(() => import('@/pages/admin/SocialManager').then(m => ({ default: m.SocialManager })));
const SEOManager = lazy(() => import('@/pages/admin/SEOManager').then(m => ({ default: m.SEOManager })));

function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <LoadingSpinner size="lg" />
    </div>
  );
}

export function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#0a0a0f',
              border: '1px solid rgba(255,255,255,0.1)',
              color: '#fff',
              backdropFilter: 'blur(10px)',
            },
            success: { iconTheme: { primary: '#00d4ff', secondary: '#0a0a0f' } },
            error: { iconTheme: { primary: '#ef4444', secondary: '#0a0a0f' } },
          }}
        />
        <Routes>
          {/* Public Routes */}
          <Route element={<MainLayout />}>
            <Route path="/" element={<Suspense fallback={<PageLoader />}><Home /></Suspense>} />
            <Route path="/about" element={<Suspense fallback={<PageLoader />}><About /></Suspense>} />
            <Route path="/projects" element={<Suspense fallback={<PageLoader />}><Projects /></Suspense>} />
            <Route path="/projects/:slug" element={<Suspense fallback={<PageLoader />}><ProjectDetail /></Suspense>} />
            <Route path="/contact" element={<Suspense fallback={<PageLoader />}><Contact /></Suspense>} />
          </Route>

          {/* Admin Routes */}
          <Route path="/admin/login" element={<Suspense fallback={<PageLoader />}><AdminLogin /></Suspense>} />
          <Route element={<AdminLayout />}>
            <Route path="/admin" element={<Suspense fallback={<PageLoader />}><AdminDashboard /></Suspense>} />
            <Route path="/admin/content" element={<Suspense fallback={<PageLoader />}><ContentManager /></Suspense>} />
            <Route path="/admin/skills" element={<Suspense fallback={<PageLoader />}><SkillsManager /></Suspense>} />
            <Route path="/admin/projects" element={<Suspense fallback={<PageLoader />}><ProjectsManager /></Suspense>} />
            <Route path="/admin/social" element={<Suspense fallback={<PageLoader />}><SocialManager /></Suspense>} />
            <Route path="/admin/seo" element={<Suspense fallback={<PageLoader />}><SEOManager /></Suspense>} />
          </Route>

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
