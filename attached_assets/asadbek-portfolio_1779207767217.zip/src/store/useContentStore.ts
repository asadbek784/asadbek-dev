import { create } from 'zustand';
import type { 
  SiteSettings, HeroSection, AboutSection, 
  Skill, Project, SocialLink, SEOSettings 
} from '@/types';

interface ContentState {
  settings: SiteSettings | null;
  hero: HeroSection | null;
  about: AboutSection | null;
  skills: Skill[];
  projects: Project[];
  socialLinks: SocialLink[];
  seo: SEOSettings | null;
  loading: boolean;
  error: string | null;

  setSettings: (s: SiteSettings) => void;
  setHero: (h: HeroSection) => void;
  setAbout: (a: AboutSection) => void;
  setSkills: (s: Skill[]) => void;
  setProjects: (p: Project[]) => void;
  setSocialLinks: (s: SocialLink[]) => void;
  setSEO: (s: SEOSettings) => void;
  setLoading: (l: boolean) => void;
  setError: (e: string | null) => void;
}

export const useContentStore = create<ContentState>((set) => ({
  settings: null,
  hero: null,
  about: null,
  skills: [],
  projects: [],
  socialLinks: [],
  seo: null,
  loading: true,
  error: null,

  setSettings: (settings) => set({ settings }),
  setHero: (hero) => set({ hero }),
  setAbout: (about) => set({ about }),
  setSkills: (skills) => set({ skills }),
  setProjects: (projects) => set({ projects }),
  setSocialLinks: (socialLinks) => set({ socialLinks }),
  setSEO: (seo) => set({ seo }),
  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),
}));
