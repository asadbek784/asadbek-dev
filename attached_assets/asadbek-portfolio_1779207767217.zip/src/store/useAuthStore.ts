import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { supabase } from '@/lib/supabase';
import type { User } from '@/types';

interface AuthState {
  user: User | null;
  session: boolean;
  loading: boolean;
  error: string | null;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  checkSession: () => Promise<void>;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      session: false,
      loading: false,
      error: null,

      signIn: async (email, password) => {
        set({ loading: true, error: null });
        try {
          const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password,
          });

          if (error) throw error;
          if (!data.user) throw new Error('No user returned');

          const user: User = {
            id: data.user.id,
            email: data.user.email!,
            role: data.user.user_metadata?.role || 'admin',
          };

          set({ user, session: true, loading: false });
        } catch (err) {
          set({ error: (err as Error).message, loading: false });
        }
      },

      signOut: async () => {
        await supabase.auth.signOut();
        set({ user: null, session: false });
      },

      checkSession: async () => {
        const { data } = await supabase.auth.getSession();
        if (data.session?.user) {
          const user: User = {
            id: data.session.user.id,
            email: data.session.user.email!,
            role: data.session.user.user_metadata?.role || 'admin',
          };
          set({ user, session: true });
        }
      },

      clearError: () => set({ error: null }),
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ user: state.user, session: state.session }),
    }
  )
);
