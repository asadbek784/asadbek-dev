import { useRef, useCallback } from 'react';
import { Canvas } from '@react-three/fiber';
import { Environment, Stars } from '@react-three/drei';
import { ParticleField } from './ParticleField';
import { FloatingObjects } from './FloatingObjects';
import { Suspense } from 'react';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';

export function Scene3D() {
  const mouse = useRef({ x: 0, y: 0 });

  const handleMouseMove = useCallback((e: MouseEvent) => {
    mouse.current.x = (e.clientX / window.innerWidth) * 2 - 1;
    mouse.current.y = (e.clientY / window.innerHeight) * 2 - 1;
  }, []);

  return (
    <div 
      className="absolute inset-0 z-0"
      onMouseMove={(e) => handleMouseMove(e.nativeEvent)}
    >
      <Canvas
        camera={{ position: [0, 0, 8], fov: 60 }}
        dpr={[1, 2]}
        gl={{ antialias: true, alpha: true }}
        style={{ background: 'transparent' }}
      >
        <Suspense fallback={null}>
          <ambientLight intensity={0.3} />
          <pointLight position={[10, 10, 10]} intensity={1} color="#00d4ff" />
          <pointLight position={[-10, -10, -10]} intensity={0.5} color="#a855f7" />
          <pointLight position={[0, 5, -5]} intensity={0.3} color="#ec4899" />

          <ParticleField mouse={mouse} count={1500} />
          <FloatingObjects />

          <Stars radius={100} depth={50} count={5000} factor={4} saturation={0.5} fade speed={1} />
          <Environment preset="city" />

          <fog attach="fog" args={['#0a0a0f', 10, 25]} />
        </Suspense>
      </Canvas>
    </div>
  );
}
