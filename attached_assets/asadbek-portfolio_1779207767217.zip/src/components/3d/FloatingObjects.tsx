import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial, Sphere, Torus, Box } from '@react-three/drei';
import * as THREE from 'three';

export function FloatingObjects() {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.getElapsedTime() * 0.1;
    }
  });

  return (
    <group ref={groupRef}>
      <Float speed={2} rotationIntensity={1.5} floatIntensity={2}>
        <Sphere args={[1, 64, 64]} position={[-3, 0, -2]}>
          <MeshDistortMaterial
            color="#00d4ff"
            transparent
            opacity={0.3}
            distort={0.4}
            speed={2}
            roughness={0.1}
            metalness={0.8}
          />
        </Sphere>
      </Float>

      <Float speed={1.5} rotationIntensity={2} floatIntensity={1.5}>
        <Torus args={[1.2, 0.3, 16, 100]} position={[3, 1, -3]} rotation={[0.5, 0, 0]}>
          <meshStandardMaterial
            color="#a855f7"
            transparent
            opacity={0.25}
            roughness={0.2}
            metalness={0.9}
            emissive="#a855f7"
            emissiveIntensity={0.2}
          />
        </Torus>
      </Float>

      <Float speed={2.5} rotationIntensity={1} floatIntensity={2.5}>
        <Box args={[1.5, 1.5, 1.5]} position={[0, 2, -4]} rotation={[0.5, 0.5, 0]}>
          <meshStandardMaterial
            color="#ec4899"
            transparent
            opacity={0.2}
            roughness={0.1}
            metalness={0.95}
            wireframe
          />
        </Box>
      </Float>

      <Float speed={1} rotationIntensity={0.5} floatIntensity={1}>
        <Sphere args={[0.5, 32, 32]} position={[2, -2, -1]}>
          <meshStandardMaterial
            color="#39ff14"
            transparent
            opacity={0.4}
            emissive="#39ff14"
            emissiveIntensity={0.5}
          />
        </Sphere>
      </Float>
    </group>
  );
}
