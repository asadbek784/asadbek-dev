export interface SiteSettings {
  id: string;
  site_name: string;
  site_title: string;
  logo_url: string | null;
  created_at: string;
}

export interface HeroSection {
  id: string;
  title: string;
  subtitle: string;
  cta_primary: string;
  cta_secondary: string;
  background_type: 'particles' | 'gradient' | 'solid';
  created_at: string;
}

export interface AboutSection {
  id: string;
  biography: string;
  experience_years: number;
  location: string;
  profile_image: string | null;
  created_at: string;
}

export interface Skill {
  id: string;
  name: string;
  icon_key: string;
  proficiency: number;
  category: 'frontend' | 'backend' | 'design' | 'tools' | 'other';
  created_at: string;
}

export interface Project {
  id: string;
  title: string;
  slug: string;
  short_description: string;
  full_description: string;
  thumbnail_url: string | null;
  featured: boolean;
  github_url: string | null;
  live_url: string | null;
  created_at: string;
  images?: ProjectImage[];
}

export interface ProjectImage {
  id: string;
  project_id: string;
  image_url: string;
  sort_order: number;
}

export interface SocialLink {
  id: string;
  platform: string;
  url: string;
  icon_key: string;
  visible: boolean;
  sort_order: number;
}

export interface SEOSettings {
  id: string;
  meta_title: string;
  meta_description: string;
  keywords: string;
  og_image_url: string | null;
}

export interface User {
  id: string;
  email: string;
  role: 'admin' | 'user';
}

export type ContentSection = 'hero' | 'about' | 'skills' | 'projects' | 'social' | 'seo';

export interface DashboardStats {
  totalProjects: number;
  totalSkills: number;
  totalViews: number;
  recentProjects: Project[];
}
