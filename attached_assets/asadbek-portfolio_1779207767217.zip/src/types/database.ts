export interface Database {
  public: {
    Tables: {
      site_settings: {
        Row: {
          id: string;
          site_name: string;
          site_title: string;
          logo_url: string | null;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['site_settings']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['site_settings']['Insert']>;
      };
      hero_section: {
        Row: {
          id: string;
          title: string;
          subtitle: string;
          cta_primary: string;
          cta_secondary: string;
          background_type: 'particles' | 'gradient' | 'solid';
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['hero_section']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['hero_section']['Insert']>;
      };
      about_section: {
        Row: {
          id: string;
          biography: string;
          experience_years: number;
          location: string;
          profile_image: string | null;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['about_section']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['about_section']['Insert']>;
      };
      skills: {
        Row: {
          id: string;
          name: string;
          icon_key: string;
          proficiency: number;
          category: 'frontend' | 'backend' | 'design' | 'tools' | 'other';
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['skills']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['skills']['Insert']>;
      };
      projects: {
        Row: {
          id: string;
          title: string;
          slug: string;
          short_description: string;
          full_description: string;
          thumbnail_url: string | null;
          featured: boolean;
          github_url: string | null;
          live_url: string | null;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['projects']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['projects']['Insert']>;
      };
      project_images: {
        Row: {
          id: string;
          project_id: string;
          image_url: string;
          sort_order: number;
        };
        Insert: Omit<Database['public']['Tables']['project_images']['Row'], 'id'>;
        Update: Partial<Database['public']['Tables']['project_images']['Insert']>;
      };
      social_links: {
        Row: {
          id: string;
          platform: string;
          url: string;
          icon_key: string;
          visible: boolean;
          sort_order: number;
        };
        Insert: Omit<Database['public']['Tables']['social_links']['Row'], 'id'>;
        Update: Partial<Database['public']['Tables']['social_links']['Insert']>;
      };
      seo_settings: {
        Row: {
          id: string;
          meta_title: string;
          meta_description: string;
          keywords: string;
          og_image_url: string | null;
        };
        Insert: Omit<Database['public']['Tables']['seo_settings']['Row'], 'id'>;
        Update: Partial<Database['public']['Tables']['seo_settings']['Insert']>;
      };
    };
  };
}
