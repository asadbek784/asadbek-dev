# 🏆 Asadbek Komilov — Next-Gen 3D Portfolio Platform

A world-class futuristic 3D developer portfolio with a fully dynamic CMS system, secure admin dashboard, and immersive cyberpunk UI.

![Tech Stack](https://img.shields.io/badge/React-18-blue?style=flat-square&logo=react)
![TypeScript](https://img.shields.io/badge/TypeScript-5.3-blue?style=flat-square&logo=typescript)
![Three.js](https://img.shields.io/badge/Three.js-WebGL-black?style=flat-square&logo=three.js)
![Supabase](https://img.shields.io/badge/Supabase-PostgreSQL-green?style=flat-square&logo=supabase)
![Tailwind](https://img.shields.io/badge/Tailwind-3.4-38B2AC?style=flat-square&logo=tailwind-css)

---

## ✨ Features

### 🎨 Frontend
- **Immersive 3D Hero** — Three.js particle field with mouse-reactive floating holographic objects
- **Cyberpunk Glassmorphism UI** — Neon gradients, blur effects, glowing borders
- **Smooth Animations** — Framer Motion powered page transitions, scroll reveals, hover effects
- **Fully Responsive** — Mobile, tablet, laptop, desktop optimized
- **SEO Optimized** — Dynamic meta tags, Open Graph images, structured data ready

### 🔐 Admin Dashboard (/admin)
- **Secure Authentication** — Supabase Auth with protected routes
- **Content Management** — Edit Hero, About, Skills, Projects, Social Links, SEO
- **Image Upload** — Direct to Supabase Storage
- **Real-time Updates** — Changes reflect immediately on the public site
- **Responsive Admin UI** — Sidebar navigation, data tables, modal editors

### 🗄️ Backend (Supabase)
- **PostgreSQL Database** — 8 tables with full CRUD operations
- **Row Level Security (RLS)** — Secure data access policies
- **File Storage** — Image uploads with public URLs
- **Authentication** — JWT-based session management

---

## 🚀 Quick Start

### 1. Clone & Install

```bash
git clone <your-repo-url>
cd asadbek-portfolio
npm install
```

### 2. Environment Setup

Create `.env` file:

```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
VITE_SITE_URL=http://localhost:5173
```

### 3. Supabase Setup

Run this SQL in your Supabase SQL Editor:

```sql
-- Site Settings
CREATE TABLE site_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  site_name TEXT NOT NULL DEFAULT 'Asadbek Komilov',
  site_title TEXT NOT NULL DEFAULT 'Creative Developer',
  logo_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Hero Section
CREATE TABLE hero_section (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL DEFAULT 'Crafting Digital Experiences',
  subtitle TEXT NOT NULL DEFAULT 'Building immersive web experiences with cutting-edge technology.',
  cta_primary TEXT NOT NULL DEFAULT 'View Projects',
  cta_secondary TEXT NOT NULL DEFAULT 'About Me',
  background_type TEXT NOT NULL DEFAULT 'particles',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- About Section
CREATE TABLE about_section (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  biography TEXT NOT NULL DEFAULT 'I am a passionate full-stack developer...',
  experience_years INTEGER NOT NULL DEFAULT 5,
  location TEXT NOT NULL DEFAULT 'Tashkent, Uzbekistan',
  profile_image TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Skills
CREATE TABLE skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  icon_key TEXT NOT NULL DEFAULT 'code',
  proficiency INTEGER NOT NULL CHECK (proficiency >= 0 AND proficiency <= 100),
  category TEXT NOT NULL CHECK (category IN ('frontend', 'backend', 'design', 'tools', 'other')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Projects
CREATE TABLE projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  short_description TEXT NOT NULL,
  full_description TEXT,
  thumbnail_url TEXT,
  featured BOOLEAN NOT NULL DEFAULT false,
  github_url TEXT,
  live_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Project Images
CREATE TABLE project_images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0
);

-- Social Links
CREATE TABLE social_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  platform TEXT NOT NULL,
  url TEXT NOT NULL,
  icon_key TEXT NOT NULL,
  visible BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER NOT NULL DEFAULT 0
);

-- SEO Settings
CREATE TABLE seo_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meta_title TEXT NOT NULL DEFAULT 'Asadbek Komilov | Creative Developer',
  meta_description TEXT NOT NULL DEFAULT 'Portfolio of Asadbek Komilov...',
  keywords TEXT NOT NULL DEFAULT 'web developer, react, portfolio',
  og_image_url TEXT
);

-- Insert default data
INSERT INTO site_settings (site_name, site_title) VALUES ('Asadbek Komilov', 'Creative Developer');
INSERT INTO hero_section (title, subtitle) VALUES ('Crafting Digital Experiences', 'Building immersive web experiences with cutting-edge technology.');
INSERT INTO about_section (biography, experience_years, location) VALUES ('I am a passionate full-stack developer...', 5, 'Tashkent, Uzbekistan');
INSERT INTO seo_settings (meta_title, meta_description, keywords) VALUES ('Asadbek Komilov | Creative Developer', 'Portfolio of Asadbek Komilov...', 'web developer, react, portfolio');

-- Enable RLS
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE hero_section ENABLE ROW LEVEL SECURITY;
ALTER TABLE about_section ENABLE ROW LEVEL SECURITY;
ALTER TABLE skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE social_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE seo_settings ENABLE ROW LEVEL SECURITY;

-- Create policies (public read, authenticated write)
CREATE POLICY "Public read" ON site_settings FOR SELECT USING (true);
CREATE POLICY "Public read" ON hero_section FOR SELECT USING (true);
CREATE POLICY "Public read" ON about_section FOR SELECT USING (true);
CREATE POLICY "Public read" ON skills FOR SELECT USING (true);
CREATE POLICY "Public read" ON projects FOR SELECT USING (true);
CREATE POLICY "Public read" ON project_images FOR SELECT USING (true);
CREATE POLICY "Public read" ON social_links FOR SELECT USING (true);
CREATE POLICY "Public read" ON seo_settings FOR SELECT USING (true);

CREATE POLICY "Authenticated write" ON site_settings FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated write" ON hero_section FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated write" ON about_section FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated write" ON skills FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated write" ON projects FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated write" ON project_images FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated write" ON social_links FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated write" ON seo_settings FOR ALL USING (auth.role() = 'authenticated');
```

### 4. Create Storage Bucket

In Supabase Dashboard:
1. Go to **Storage** → **New bucket**
2. Name: `portfolio-assets`
3. Set **Public bucket**
4. Create policy: `Allow public access` for `SELECT`
5. Create policy: `Allow authenticated uploads` for `INSERT`

### 5. Run Development Server

```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

---

## 📁 Project Structure

```
src/
├── components/
│   ├── 3d/           # Three.js components (Scene, Particles, FloatingObjects)
│   ├── sections/     # Page sections
│   └── ui/           # Reusable UI (GlassCard, SectionTitle, LoadingSpinner)
├── pages/
│   ├── Home.tsx      # Landing page with 3D hero
│   ├── About.tsx     # About & skills
│   ├── Projects.tsx  # Project grid with search/filter
│   ├── ProjectDetail.tsx # Individual project page
│   ├── Contact.tsx   # Contact form
│   └── admin/        # Admin pages (Login, Dashboard, Content, Skills, Projects, Social, SEO)
├── layouts/
│   ├── MainLayout.tsx   # Public site layout with nav
│   └── AdminLayout.tsx  # Admin dashboard layout
├── store/
│   ├── useAuthStore.ts    # Zustand auth state
│   └── useContentStore.ts # Zustand content state
├── services/
│   ├── contentService.ts  # Supabase CRUD operations
│   └── storageService.ts  # File upload operations
├── hooks/
│   ├── useContent.ts      # Fetch all content
│   └── useAuth.ts         # Auth session check
├── animations/
│   └── variants.ts        # Framer Motion variants
├── types/
│   ├── index.ts           # TypeScript interfaces
│   └── database.ts        # Supabase DB types
├── lib/
│   └── supabase.ts        # Supabase client
├── App.tsx               # Router setup
└── main.tsx              # Entry point
```

---

## 🛡️ Security

- ✅ Row Level Security (RLS) enabled on all tables
- ✅ Protected admin routes with auth guards
- ✅ Environment variables for sensitive keys
- ✅ Form validation on all inputs
- ✅ Secure file upload validation

---

## 🚀 Deployment

### Vercel (Recommended)

```bash
npm install -g vercel
vercel
```

Add environment variables in Vercel Dashboard:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_SITE_URL`

---

## 🎨 Design System

| Token | Value |
|-------|-------|
| Primary | `#00d4ff` (Cyber Blue) |
| Secondary | `#a855f7` (Purple) |
| Accent | `#ec4899` (Pink) |
| Background | `#0a0a0f` (Dark) |
| Glass | `rgba(255,255,255,0.05)` |
| Border | `rgba(255,255,255,0.1)` |

---

## 📄 License

MIT License — feel free to use and modify for your own portfolio.

---

Built with 💙 by **Asadbek Komilov**
